# Gatsby Tailwind PurgeCSS Starter

* Includes PostCSS
    * autoprefixer
    * purgecss
* Includes FontAwesome
* Includes TailwindCSS
